<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-user" aria-hidden="true"></i> <span class="title">Ownership Types</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.ownership.types') }}" class="nav-link "> <span class="title">List Ownership Types</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.ownership.type') }}" class="nav-link ">  <span class="title">Add new Ownership Type</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.ownership.types') }}" class="nav-link ">  <span class="title">Sort Ownership Types</span> </a> </li>
    </ul>
</li>