<div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="userccount">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h5>{{__('Update Language')}}</h5>            
                        <div class="formpanel">
                            <div class="formrow">
                                <h3>{{__('Language Updated successfully')}}</h3>
                            </div>                
                        </div>            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
